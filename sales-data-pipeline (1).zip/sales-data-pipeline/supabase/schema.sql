-- Run this in the Supabase SQL editor (or via `supabase db push`) to set up the warehouse table.

create table public.sales_consolidated (
  id bigint generated always as identity primary key,
  source text not null,
  "recordId" text not null unique,
  "recordDate" text,
  customer text,
  amount numeric,
  currency text,
  inserted_at timestamptz not null default now()
);

create index sales_consolidated_source_idx on public.sales_consolidated (source);
create index sales_consolidated_record_date_idx on public.sales_consolidated ("recordDate");

-- Optional: enable Row Level Security before exposing this table via Supabase's public API.
-- alter table public.sales_consolidated enable row level security;
